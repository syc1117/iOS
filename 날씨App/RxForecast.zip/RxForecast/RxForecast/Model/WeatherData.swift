//
//  WeatherData.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxCocoa
import RxDataSources

struct WeatherData: WeatherDataType, Equatable {
   let date: Date?
   let weatherCode: String
   let weatherDescription: String
   let temperature: Double
   let maxTemperature: Double?
   let minTemperature: Double?
}

extension WeatherData {
   init(summary: WeatherSummary) {
      date = Date()
      weatherCode = summary.weather.minutely[0].sky.code
      weatherDescription = summary.weather.minutely[0].sky.name
      temperature = Double(summary.weather.minutely[0].temperature.tc) ?? 0
      maxTemperature = Double(summary.weather.minutely[0].temperature.tmax) ?? 0
      minTemperature = Double(summary.weather.minutely[0].temperature.tmin) ?? 0
   }
}

extension WeatherData: IdentifiableType {
   var identity: Double {
      return date?.timeIntervalSinceReferenceDate ?? 0
   }
}

