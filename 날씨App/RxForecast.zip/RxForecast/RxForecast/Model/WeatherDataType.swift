//
//  WeatherDataType.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation

protocol WeatherDataType {
   var date: Date? { get }
   var weatherCode: String { get }
   var weatherDescription: String { get }
   var temperature: Double { get }
   var maxTemperature: Double? { get }
   var minTemperature: Double? { get }
}

