//
//  TransitionModel.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation

enum TransitionStyle {
   case root
   case push
   case modal
}


enum TransitionError: Error {
   case navigationControllerMissing
   case cannotPop
   case unknown
}

