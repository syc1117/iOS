//
//  ApiKey.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation

let apiKey = "6155794b-0982-44a4-b216-f54008fe7548"
