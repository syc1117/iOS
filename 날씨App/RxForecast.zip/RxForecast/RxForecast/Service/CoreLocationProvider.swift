//
//  CoreLocationProvider.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit
import CoreLocation
import RxSwift
import RxCocoa
import NSObject_Rx

class CoreLocationProvider: LocationProviderType, HasDisposeBag {
    
    private let locationManager = CLLocationManager()
    
    private let location = BehaviorRelay<CLLocation>(value: CLLocation.gangnamStation)
    
    private let address = BehaviorRelay<String>(value: "강남역")
    
    private let authorized = BehaviorRelay<Bool>(value: false)
    
    init() {
        locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        locationManager.rx.didUpdateLocation
            .throttle(.seconds(2), scheduler: MainScheduler.instance)
            .map { $0.last ?? CLLocation.gangnamStation }
            .bind(to: location)
            .disposed(by: disposeBag)
        
        location
            .flatMap { location in
                return Observable<String>.create { observer in
                    let decoder = CLGeocoder()
                    decoder.reverseGeocodeLocation(location) { (placemarks, error) in
                        if let place = placemarks?.first {
                            if let gu = place.locality, let dong = place.subLocality {
                                observer.onNext("\(gu) \(dong)")
                            } else {
                                observer.onNext(place.name ?? "알 수 없음")
                            }
                        } else {
                            observer.onNext("알 수 없음")
                        }
                        observer.onCompleted()
                    }
                    return Disposables.create {
                        decoder.cancelGeocode()
                    }
                }
        }
        .bind(to: address)
        .disposed(by: disposeBag)
        
        locationManager.rx.didChangeAuthorizationStatus
            .map { $0 == .authorizedWhenInUse || $0 == .authorizedAlways }
            .bind(to: authorized)
            .disposed(by: disposeBag)
    }
    
    @discardableResult
    func currenLocation() -> Observable<CLLocation> {
        return location.asObservable()
    }
    
    @discardableResult
    func currentAddress() -> Observable<String> {
        return address.asObservable()
    }
    
    
}
