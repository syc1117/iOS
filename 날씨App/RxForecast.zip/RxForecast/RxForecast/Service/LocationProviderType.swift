//
//  LocationProviderType.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import CoreLocation
import RxSwift

protocol LocationProviderType {
    @discardableResult
    func currenLocation() -> Observable<CLLocation>
    
    @discardableResult
    func currentAddress() -> Observable<String>
}
