//
//  WeatherApiType.swift
//  RxForecast
//
//  Created by 신용철 on 2020/07/08.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import CoreLocation
import RxSwift

protocol WeatherApiType {
    //api서비스가 공통적으로 구현하는 method 선언
   @discardableResult
    //위치정보를 param으로 받아서 현재날씨 + [날씨예보]를 tuple형식의 observable 리턴
    func fetch(location: CLLocation) -> Observable<(WeatherDataType?, [WeatherDataType])>
}
