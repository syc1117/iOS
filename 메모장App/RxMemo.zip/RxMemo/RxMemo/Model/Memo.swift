//
//  Memo.swift
//  RxMemo
//
//  Created by 신용철 on 2020/06/30.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxDataSources // IdentifiableType이 반드시 필요
import CoreData
import RxCoreData

struct Memo: Equatable, IdentifiableType {
    var content: String // 메모 내용
    var insertDate: Date // 메모 생성 날짜
    var identity: String  // 메모 구분자. 메모 수정시 사용.
    
    init(content: String, insertDate: Date = Date()) {
        self.content = content
        self.insertDate = insertDate
        self.identity = "\(insertDate.timeIntervalSinceReferenceDate)"
        //timeIntervalSinceReferenceDate: 21세기 시작 지점 2001. 1. 1 00:00:00 UTC를 기준으로 TimeInterval만큼 후의 시간
    }
    
    //update된 내용으로 새로운 Memo 인스턴스를 생성 :content를 제외한 나머지가 모두 동일한, 즉, content만 바뀐 Memo인스턴스 생성
    init(original: Memo, updatedContent: String) {
        self = original
        self.content = updatedContent
    }
}

//Persistable:
extension Memo: Persistable {
    public static var entityName: String {
        return "Memo"
    }
    
    static var primaryAttributeName: String {
        return "identity"
    }
    
    init(entity: NSManagedObject) {
        content = entity.value(forKey: "content") as! String
        insertDate = entity.value(forKey: "insertDate") as! Date
        identity = "\(insertDate.timeIntervalSinceReferenceDate)"
    }
    
    func update(_ entity: NSManagedObject) {
        entity.setValue(content, forKey: "content")
        entity.setValue(insertDate, forKey: "insertDate")
        entity.setValue("\(insertDate.timeIntervalSinceReferenceDate)", forKey: "identity")
        
        do {
            try entity.managedObjectContext?.save()
        } catch {
            print(error)
        }
    }
}
