//
//  Scene.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/04.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit

//앱에서 구현할 Scene을 열거형으로 선언

enum Scene {
    case list(MemoListViewModel)
    case detail(MemoDetailViewModel)
    case compose(MemoComposeViewModel)
}
//스토리보드에 있는 Scene을 생성하고 관련 ViewModel을 binding해서 return하는 함수 구현
extension Scene {
    func instantiate(from storyboard: String = "Main") -> UIViewController {
        let storyboard = UIStoryboard(name: storyboard, bundle: nil)
        
        switch self {
        //MemoList Scene생성 후 viewModel을 binding해서 return
        case .list(let viewModel): //(let viewModel)은 case .list의 관련값으로 MemoListViewModel을 의미함.
            guard let nav = storyboard.instantiateViewController(withIdentifier: "ListNav") as? UINavigationController else { fatalError() }
            
            guard var listVC = nav.viewControllers.first as? MemoListViewController else { fatalError() }
            
            listVC.bind(viewModel: viewModel)
            return nav //return값이 UIViewController이고, listVC가 아닌 nav를 return해야함.
        //메모보기 화면은 항상 navigationController에 push되기 때문에 별도로 nav를 고려할 필요 없음.
        case .detail(let viewModel):
            guard var detailVC = storyboard.instantiateViewController(withIdentifier: "DetailVC") as? MemoDetailViewController else {fatalError()}
            
            detailVC.bind(viewModel: viewModel)
            return detailVC
            
        case .compose(let viewModel):
            guard let nav = storyboard.instantiateViewController(withIdentifier: "ComposeNav") as? UINavigationController else { fatalError()}
            
            guard var composeVC = nav.viewControllers.first as? MemoComposeViewController else { fatalError()}
            
            composeVC.bind(viewModel: viewModel)
            return nav
        }
    }
}
