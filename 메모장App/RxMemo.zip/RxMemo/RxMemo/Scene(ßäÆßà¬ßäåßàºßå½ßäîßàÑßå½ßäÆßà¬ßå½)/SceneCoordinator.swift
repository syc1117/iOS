//
//  SceneCoordinator.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/04.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

//SceneCoordinator에서 case .push가 else문을 타면서 detailView가 열리지 않는 현상이 발생함.
//이는 currentVC에 memoListViewController가 아닌 nav가 들어가 있기 때문임. 이 문제를 해결하기 위해 아래 extension필요
extension UIViewController {
    //실제 화면에 표시되어있는 View를 표시
    var sceneViewController: UIViewController {
        return self.children.first ?? self //nav면 마지막 child return, 아니면 그냥 자기자신
    }
}

class SceneCoordinator: SceneCoordinatorType {
    private let bag = DisposeBag()
    
    //화면 전환을 수행하기 위해서는 window인스턴스와 현재 Scene을 가지고 있어야함.
    private var window: UIWindow
    private var currentVC: UIViewController
    
    required init(window: UIWindow) {
        self.window = window
        currentVC = window.rootViewController!
    }
    
    @discardableResult
    func transition(to scene: Scene, using style: TransitionStyle, animated: Bool) -> Completable {
        //전환 결과를 방출할 subject 선언
        let subject = PublishSubject<Void>()
        //새로운 scene을 생성해서 상수에 담는다
        let target = scene.instantiate() //파라미터 입력 안했으므로 기본값인 "Main"이 들어감
        
        switch style {
        case .root: //rootView로 설정해주기
            currentVC = target.sceneViewController
            window.rootViewController = target
            subject.onCompleted()
        case .push: //push는 nav에 embeded되었을 때만 의미가 있으므로, 이를 확인하고 아니면 error띄우고 종료
            guard let nav = currentVC.navigationController else {
                subject.onError(TransitionError.navigationControllerMissing)
                break
            }
            nav.rx.willShow //nav에서 화면전환 직전에 호출되는 delegate기능.
                .subscribe(onNext: { [unowned self] evt in
                    self.currentVC = evt.viewController.sceneViewController
                })
                .disposed(by: bag)
            nav.pushViewController(target, animated: animated)
            currentVC = target.sceneViewController
            
            subject.onCompleted()
        case .modal: //present
            currentVC.present(target, animated: animated) {
                subject.onCompleted()
            }
            currentVC = target.sceneViewController
        }
        
        return subject.ignoreElements()// subject에 ignoreElements()붙이면 Completable로 변환됨.
    }
    
    @discardableResult
    func close(animated: Bool) -> Completable {
        return Completable.create { [unowned self] completable in
            //현재 화면이 어떤 방식으로(modal, push)에 따라 어떻게 작동할지 설정
            if let presentingVC = self.currentVC.presentingViewController {
                self.currentVC.dismiss(animated: animated) {
                    self.currentVC = presentingVC.sceneViewController
                    completable(.completed)
                }
                
            } else if let nav = self.currentVC.navigationController {
                guard nav.popViewController(animated: animated) != nil else {
                    completable(.error(TransitionError.cannotPop))
                    return Disposables.create()
                }
                self.currentVC = nav.viewControllers.last!
                completable(.completed)
                
            } else {
                completable(.error(TransitionError.unknown))
            }
            return Disposables.create()
        }
    }
    
    
}
