//
//  SceneCoordinatorType.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/04.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift

protocol SceneCoordinatorType {
    @discardableResult//return값 사용안하면 발생하는 컴파일러 오류 무시해줌
    //새로 띄울 화면을 세팅 - 대상 화면이 무엇인지(scene), modal방식은 뭔지
    //return형 Completable: 여기에 구독자를 추가하면 화면전환 완료시 원하는 작업을 수행할 수 있음. 필요없으면 사용안해도 되는 것.
    func transition(to scene: Scene, using style: TransitionStyle, animated: Bool) -> Completable
    
    @discardableResult
    //화면 닫기
    //return형 Completable: 여기에 구독자를 추가하면 화면전환 완료시 원하는 작업을 수행할 수 있음. 필요없으면 사용안해도 되는 것.
    func close(animated: Bool) -> Completable
}
