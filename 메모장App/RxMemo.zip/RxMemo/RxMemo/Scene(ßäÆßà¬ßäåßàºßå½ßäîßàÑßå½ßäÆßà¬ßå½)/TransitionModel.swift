//
//  TransitionModel.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/04.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation

//전환 방식 표현하는 열거형 선언
enum TransitionStyle {
    case root
    case push
    case modal
}

//표시할 에러 형태
enum TransitionError: Error {
    case navigationControllerMissing
    case cannotPop
    case unknown
}
