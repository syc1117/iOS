//
//  MemoryStorage.swift
//  RxMemo
//
//  Created by 신용철 on 2020/06/30.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift

//Memory에 Memo저장
/*
 핵심개념:
 1. 아래 Memo배열(var list)는 Obsevable을 통해 외부에서 접근할 수 있게 되어있음.
 2. 또한, 배열이 update되면 Obsevable은 새로운 event를 방출해야함. 단순히 Observable로 만들면 이것이 불가능하기 때문에, subject를 사용해야함.
 3. 초기에 기존 데이터를 표시해주어야 하기 때문에 BehaviorSubject를 사용해야함.
 */
class MemoryStorage: MemoStorageType {
    private var list = [
        Memo(content: "Hello, RxSwift", insertDate: Date().addingTimeInterval(-10)),
        Memo(content: "Hello, RxSwift2", insertDate: Date().addingTimeInterval(-20))
    ]
    
    private lazy var sectionModel = MemoSectionModel(model: 0, items: list)
    
    //초기값을 같는 + Memo가 배열에 추가될때 마다 구독을 할 수 있는 subject 사용한 것.
    //lazy : 초기값으로 list를 사용하기 위함.
    private lazy var store = BehaviorSubject<[MemoSectionModel]>(value: [sectionModel])
    
    @discardableResult
    func createMemo(content: String) -> Observable<Memo> {
        let memo = Memo(content: content)
        sectionModel.items.insert(memo, at: 0)
        
        //새로운 Memo가 추가된 Memo배열을 방출 - TableView와 바인딩해서 목록이 항상 최신화 되도록하기 위함. reload사용할 필요 없음.
        store.onNext([sectionModel])
        
        return Observable.just(memo)
    }
    
    @discardableResult
    func memoList() -> Observable<[MemoSectionModel]> {
        //return 타입이 Observable이면 subject를 return해도 됨.
        return store
    }
    
    @discardableResult
    func update(memo: Memo, content: String) -> Observable<Memo> {
        let update = Memo(original: memo, updatedContent: content)
        
        //원래 있던 Memo를 update로 교체
        if let index = sectionModel.items.firstIndex(of: memo) {
            sectionModel.items.remove(at: index)
            sectionModel.items.insert(update, at: index)
        }
        //수정된 Memo배열을 방출 - 방출된 것을 어디서 구독하는지 확인해야됨.
        store.onNext([sectionModel])
        
        return Observable.just(update)
    }
    
    @discardableResult
    func delete(memo: Memo) -> Observable<Memo> {
        if let index = sectionModel.items.firstIndex(of: memo) {
            sectionModel.items.remove(at: index)
        }
        
        store.onNext([sectionModel])
        
        return Observable.just(memo)
    }
    
    
}
