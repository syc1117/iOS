//
//  MemoStorageType.swift
//  RxMemo
//
//  Created by 신용철 on 2020/06/30.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift

//Memory 저장소 구현
protocol MemoStorageType {
    //CURD 구현
    @discardableResult
    func createMemo(content: String) -> Observable<Memo>
    
    @discardableResult
    func memoList() -> Observable<[MemoSectionModel]>
    
    @discardableResult
    func update(memo: Memo, content: String) -> Observable<Memo>
    
    @discardableResult
    func delete(memo: Memo) -> Observable<Memo>
}
