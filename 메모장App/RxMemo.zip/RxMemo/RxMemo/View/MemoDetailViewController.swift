//
//  MemoDetailViewController.swift
//  RxMemo
//
//  Created by 신용철 on 2020/06/30.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa


class MemoDetailViewController: UIViewController, ViewModelBindableType {
    
    var viewModel: MemoDetailViewModel!
    
    @IBOutlet weak var listTableView: UITableView!
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var editButton: UIBarButtonItem!
    @IBOutlet weak var deleteButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    func bindViewModel() {
        viewModel.title.drive(navigationItem.rx.title).disposed(by: rx.disposeBag)
        
        viewModel.contents
            .bind(to: listTableView.rx.items) { tableView, row, value in
                switch row {
                case 0:
                    let cell = tableView.dequeueReusableCell(withIdentifier: "contentCell")!
                    cell.textLabel?.text = value
                    return cell
                case 1:
                    let cell = tableView.dequeueReusableCell(withIdentifier: "dateCell")!
                    cell.textLabel?.text = value
                    return cell
                default:
                    fatalError()
                }
        }
        .disposed(by: rx.disposeBag)
        
        //편집버튼 구현
        editButton.rx.action = viewModel.makeEditAction()
        
        //삭제버튼 구현
        deleteButton.rx.action = viewModel.makeDeleteAction()
        
        //공유기능 구현(tab사용): tab과 action의 차이점(장단점)확인 할 것.
        shareButton.rx.tap
            .throttle(.microseconds(500), scheduler: MainScheduler.instance).subscribe(onNext: {
                [weak self] _ in
                guard let memo = self?.viewModel.memo.content else { return }
                
                let vc = UIActivityViewController(activityItems: [memo], applicationActivities: nil)
                self?.present(vc, animated: true, completion: nil)
            })
            .disposed(by: rx.disposeBag)
    }
    

}
