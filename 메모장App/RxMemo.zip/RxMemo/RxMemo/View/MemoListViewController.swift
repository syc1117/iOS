//
//  MemoListViewController.swift
//  RxMemo
//
//  Created by 신용철 on 2020/06/30.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import NSObject_Rx

class MemoListViewController: UIViewController, ViewModelBindableType {
    
    var viewModel: MemoListViewModel!
    //Rx에서는 tableView DataSource를 사용하지 않고 obsevable과 tableView를 바인딩하는 방식을 사용함. DataSource연결하면 바인딩이 정상적으로 동적하지 않음.
    @IBOutlet weak var listTableView: UITableView!
    
    //IBAction을 사용하지 않고 Rxcocoa가 추가한 tab속성을 구독하거나 action속성에 직접 action을 구현하는 방식을 사용함.
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    //viewModel 과 view를 binding
    func bindViewModel() {
        //viewModel에 저장된 title을 nav title과 binding -> viewModel에 저장된 title을 view에 표시
        viewModel.title
            .drive(navigationItem.rx.title)
            .disposed(by: rx.disposeBag)
        
        //Memo목록을 tableView에 바인딩: obsevable과 Tableview를 바인딩
        viewModel.memoList
            .bind(to: listTableView.rx.items(dataSource: viewModel.dataSource))
            .disposed(by: rx.disposeBag)
        
        addButton.rx.action = viewModel.makeCreateAction()
        
        //tableView에서 memo를 선택하면 ViewModel을 통해 detailAction 전달 + 선택한 cell은 선택해제
        //위 작업을 위해 선택한 memo, indexPath가 필요 -> RxCocoa의 modelSelected 메서드 + itemSelected 속성
        Observable
            //선택된 Memo와 indexPath를 tuple형태로 방출
            .zip(listTableView.rx.modelSelected(Memo.self), listTableView.rx.itemSelected)
            //next이벤트가 전달되면 선택 해제
            .do(onNext: {[unowned self] (_, indexPath) in
                self.listTableView.deselectRow(at: indexPath, animated: true)
            })
            //선택해제 완료 된 후에는 indexPath가 불필요 하므로 Memo만 방출하도록 함.
            .map { $0.0 }
            //전달된 Memo를 detailAction과 binding
            .bind(to: viewModel.detailAction.inputs)
            .disposed(by: rx.disposeBag)
        
        
        //tableView swipe 삭제 기능 구현 (delegate 미사용, RxCocoa사용)
        listTableView.rx.modelDeleted(Memo.self) //Control Event 리턴 -> 메모 삭제할 때마다 next방출
            .bind(to: viewModel.deleteAction.inputs) //자동으로 swipe와 연동
            .disposed(by: rx.disposeBag)
    }
}
