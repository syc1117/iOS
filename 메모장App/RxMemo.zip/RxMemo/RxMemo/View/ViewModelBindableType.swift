//
//  ViewModelBindableType.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/02.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit
//각 화면별로 ViewModel이 있는데 그 뷰모델들을 뷰와 연결시키기 위해 공통적으로 구현해야하는 속성들을 정의
protocol ViewModelBindableType {
    //ViewModel의 타입은 Controller마다 다르기때문에 protocol을 generic(타입을 미리 특정짓지않음)으로 선언함. 변수에 서로 다른 viewController가 매칭될 수 있기 때문임.
    associatedtype ViewModelType
    
    var viewModel: ViewModelType! { get set }

    func bindViewModel()
}

//viewController에 추가된 ViewModel 속성의 실제 ViewModel을 저장하고 func bindViewModel()을 자동으로 호출하는 method 구현
extension ViewModelBindableType where Self: UIViewController {
    //Self: 상속받게 될 주체를 가리킴: 여기서는 해당 프로토콜을 채택하는 각 ViewController가 해당됨.
    mutating func bind(viewModel: Self.ViewModelType) { //Self.ViewModelType 아무 의미 없음. 단지 어떤 타입이라는 것뿐임.
    //mutating: 구조체에서 선언된 변수를 자체 함수에서 값변경 해주려고 할 때 사용하는 키워드
        self.viewModel = viewModel //mutating이 필요한 이유
        loadViewIfNeeded()//view가 아직 load가 안되었으면 load를 강제로 시킴
        
        bindViewModel()
    }
    
}
