//
//  CommonViewModel.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/04.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

//지금 메모 app에서는 모두 nav에 embeded되어 있기 때문에 title정보가 필요함.
class CommonViewModel: NSObject {
    let title: Driver<String>
    //protocol타입으로 선언하여 의존성 주입을 용이하게 함.
    let sceneCoordinator: SceneCoordinatorType
    let storage: MemoStorageType
    
    init(title: String, sceneCoordinator: SceneCoordinatorType, storage: MemoStorageType) {
        self.title = Observable.just(title).asDriver(onErrorJustReturn: "")
        self.sceneCoordinator = sceneCoordinator
        self.storage = storage
    }
}
