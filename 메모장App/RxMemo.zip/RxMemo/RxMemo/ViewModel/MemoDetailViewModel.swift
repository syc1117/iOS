//
//  MemoDetailViewModel.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/02.
//  Copyright © 2020 신용철. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import Action

class MemoDetailViewModel: CommonViewModel {
    var memo: Memo // 이전 화면에서 전달된 메모내용 전달
    
    private var formatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "Ko_kr")
        f.dateStyle = .long
        f.timeStyle = .short
        return f
    }()
    
    var contents: BehaviorSubject<[String]> // 메모 편집후 다시 메모 보기로 돌아오면 변경사항이 저장되어야 하기 때문에 BehaviorSubject사용함.
    
    init(memo: Memo, title: String, sceneCoordinator: SceneCoordinatorType, storage: MemoStorageType) {
        self.memo = memo
        
        contents = BehaviorSubject<[String]>(value: [
            memo.content,
            formatter.string(from: memo.insertDate)
        ])
        
        super.init(title: title, sceneCoordinator: sceneCoordinator, storage: storage)
    }
    
   lazy var popAction = CocoaAction { [unowned self] in
       return self.sceneCoordinator.close(animated: true).asObservable().map { _ in }
   }
    
    func performUpdate(memo: Memo) -> Action<String, Void> {
        return Action { input in
            //빈 메모를 먼저 만들고 업데이트 하는 방식
            self.storage.update(memo: memo, content: input)
                //메모를 편집했을 경우 편집된 메모 내용이 메모보기화면에 바로 업데이트 되도록, 업데이트 된 Memo를 subject에 전달하고 서브젝트는 변경사항을 다시 방출 -> reload 효과
                .subscribe(onNext: { updated in
                    
                    self.memo = updated //메모보기화면에서 편집버튼 한번 더 클릭 했을 때 바꾼내용으로 안바뀌는 현상 해결
                    
                    self.contents.onNext([
                        updated.content,
                        self.formatter.string(from: updated.insertDate)
                    ])
                })
                .disposed(by: self.rx.disposeBag)
            
            return Observable.empty()
        }
    }
    
    //메모보기 화면의 편집버튼과 binding할 action 필요
    func makeEditAction() -> CocoaAction {
        return CocoaAction { _ in
            let composeViewModel = MemoComposeViewModel(title: "메모 편집", content: self.memo.content, sceneCoordinator: self.sceneCoordinator, storage: self.storage, saveAction: self.performUpdate(memo: self.memo))
            
            let composeScene = Scene.compose(composeViewModel)
            
            return self.sceneCoordinator.transition(to: composeScene, using: .modal, animated: true).asObservable().map{ _ in }
        }
    }
    
    func makeDeleteAction() -> CocoaAction {
        return Action { input in
            self.storage.delete(memo: self.memo)
            return self.sceneCoordinator.close(animated: true).asObservable().map { _ in }
        }
    }
}
