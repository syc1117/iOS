//
//  MemoListViewModel.swift
//  RxMemo
//
//  Created by 신용철 on 2020/07/02.
//  Copyright © 2020 신용철. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import Action
import RxDataSources

//RxDataSources가 제공하는 기본 sectionModel
//Memo목록은 하나의 section에서 표시되고, section Header, Footer모두 없음 -> SectionData 신경쓸 필요 없음.
typealias MemoSectionModel = AnimatableSectionModel<Int, Memo>
//의존성 주입 생성자, binding에 사용되는 속성과 method가 필요함.
//화면 전환 + 메모 저장기능
class MemoListViewModel: CommonViewModel {
    let dataSource: RxTableViewSectionedReloadDataSource<MemoSectionModel> = {
       let ds = RxTableViewSectionedReloadDataSource<MemoSectionModel>(configureCell: {
        (dataSource, tableView, indexPath, memo) -> UITableViewCell in
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = memo.content
        return cell
       })
        
        ds.canEditRowAtIndexPath = { _, _ in return true }
        return ds
    }()
    //tableView와 binding할 수 있는 memo속성 추가, Memo배열 방출
    var memoList: Observable<[MemoSectionModel]> {
        return storage.memoList()
    }
    
    func performUpdate(memo: Memo) -> Action<String, Void> {
        return Action { input in
            //빈 메모를 먼저 만들고 업데이트 하는 방식
            return self.storage.update(memo: memo, content: input).map { _ in }
        }
    }
    
    func performCancel(memo: Memo) -> CocoaAction {
        return Action {
            //빈메모를 먼저 생성해 놨기 때문에 취소할 때 지워줘야 함.
            return self.storage.delete(memo: memo).map{ _ in }
        }
    }
    
    func makeCreateAction() -> CocoaAction {
        return CocoaAction { _ in
            return self.storage.createMemo(content: "")
                .flatMap { memo -> Observable<Void> in
                    let composeViewModel = MemoComposeViewModel(title: "새메모", sceneCoordinator: self.sceneCoordinator, storage: self.storage, saveAction: self.performUpdate(memo: memo), cancelAction: self.performCancel(memo: memo))
                    
                    let composeScene = Scene.compose(composeViewModel)
                    
                    //completable을 리넡하기 때문에 .map { _ in }로 void형식을 방출하는 observable로 만들어 주어야 함.
                    return self.sceneCoordinator.transition(to: composeScene, using: .modal, animated: true).asObservable().map { _ in }
            }
            
        }
    }
    
    lazy var detailAction: Action<Memo, Void> = {
        return Action { memo in
            
            let detailViewModel = MemoDetailViewModel(memo: memo, title: "메모보기", sceneCoordinator: self.sceneCoordinator, storage:  self.storage)
            
            let detailScene = Scene.detail(detailViewModel)
            
            return self.sceneCoordinator.transition(to: detailScene, using: .push, animated: true).asObservable().map { _ in }
        }
    }()
    
    lazy var deleteAction: Action<Memo, Swift.Never> = {
        return Action { memo in
            return self.storage.delete(memo: memo).ignoreElements()
        }
    }()
}
